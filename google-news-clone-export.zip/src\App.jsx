import React, { useState, useEffect } from 'react';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { CategoryPills } from './components/common/CategoryPills';
import { BreakingBanner } from './components/feed/BreakingBanner';
import { TopStoryCard } from './components/feed/TopStoryCard';
import { SectionBlock } from './components/feed/SectionBlock';
import { ArticleCard } from './components/feed/ArticleCard';
import { EditorsPicksWidget } from './components/feed/EditorsPicksWidget';
import { WeatherWidget } from './components/feed/WeatherWidget';
import { ArticleDetail } from './components/article/ArticleDetail';
import { SearchResults } from './components/search/SearchResults';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { ArticleEditor } from './components/admin/ArticleEditor';
import { AdminLogin } from './components/admin/AdminLogin';
import { storageService } from './services/storageService';
import { useAuth, AuthProvider } from './context/AuthContext';

function MainApp() {
  const { isLoggedIn, isAuthModalOpen, closeAuthModal } = useAuth();
  
  const [categories, setCategories] = useState([]);
  const [articles, setArticles] = useState([]);
  const [activeCategory, setActiveCategory] = useState('home');
  
  // Navigation View State
  const [currentView, setCurrentView] = useState('home'); // 'home', 'article', 'search', 'admin-dashboard', 'admin-editor'
  const [selectedArticleId, setSelectedArticleId] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  
  // Layout States
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [visibleArticleLimit, setVisibleArticleLimit] = useState(6);

  // Initialize & Load Data
  useEffect(() => {
    storageService.init();
    setCategories(storageService.getCategories());
    loadArticles();
  }, [currentView, activeCategory]);

  const loadArticles = () => {
    const fetched = storageService.getArticles(false); // Only published for public site
    setArticles(fetched);
  };

  // Dark Mode toggle
  useEffect(() => {
    if (darkMode) {
      document.body.classList.add('dark-theme');
    } else {
      document.body.classList.remove('dark-theme');
    }
  }, [darkMode]);

  // Handlers
  const handleOpenArticle = (id) => {
    setSelectedArticleId(id);
    setCurrentView('article');
    window.scrollTo(0, 0);
  };

  const handleSearchSubmit = (query) => {
    setSearchQuery(query);
    const results = storageService.searchArticles(query, false);
    setSearchResults(results);
    setCurrentView('search');
    window.scrollTo(0, 0);
  };

  const handleSelectCategory = (catSlug) => {
    setActiveCategory(catSlug);
    setCurrentView('home');
    setVisibleArticleLimit(6);
    window.scrollTo(0, 0);
  };

  const handleEditArticleFromAdmin = (id) => {
    setSelectedArticleId(id);
    setCurrentView('admin-editor');
    window.scrollTo(0, 0);
  };

  const handleCreateNewArticle = () => {
    setSelectedArticleId(null);
    setCurrentView('admin-editor');
    window.scrollTo(0, 0);
  };

  // Filter articles based on active category
  const categoryArticles = activeCategory === 'home' || activeCategory === 'all'
    ? articles
    : articles.filter(a => a.category.toLowerCase() === activeCategory.toLowerCase());

  // Find Featured & Breaking stories
  const breakingArticle = articles.find(a => a.breaking_flag);
  const featuredArticle = categoryArticles.find(a => a.featured_flag) || categoryArticles[0];
  const relatedToFeatured = featuredArticle ? articles.filter(a => a.id !== featuredArticle.id && a.category === featuredArticle.category).slice(0, 3) : [];

  // Group remaining articles by sections for 'home' feed
  const techArticles = articles.filter(a => a.category === 'technology');
  const worldArticles = articles.filter(a => a.category === 'world');
  const businessArticles = articles.filter(a => a.category === 'business');
  const sportsArticles = articles.filter(a => a.category === 'sports');

  return (
    <div className="app-layout">
      
      {/* Header */}
      <Header
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        currentCategory={activeCategory}
        onSelectCategory={handleSelectCategory}
        onOpenArticle={handleOpenArticle}
        onSearchSubmit={handleSearchSubmit}
        currentView={currentView}
        setCurrentView={setCurrentView}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {/* Sidebar Navigation */}
      <Sidebar
        categories={categories}
        activeCategory={activeCategory}
        onSelectCategory={handleSelectCategory}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        currentView={currentView}
        setCurrentView={setCurrentView}
      />

      {/* Main Page Area */}
      <div className="main-content-wrapper">
        <main className="content-body" style={{ marginLeft: 'var(--sidebar-width)' }}>
          
          {/* Admin Login Modal */}
          {isAuthModalOpen && <AdminLogin onClose={closeAuthModal} />}

          {/* View 1: Article Reader */}
          {currentView === 'article' && (
            <ArticleDetail
              articleId={selectedArticleId}
              onBack={() => setCurrentView('home')}
              onOpenArticle={handleOpenArticle}
              onEditArticle={handleEditArticleFromAdmin}
            />
          )}

          {/* View 2: Search Results */}
          {currentView === 'search' && (
            <SearchResults
              query={searchQuery}
              results={searchResults}
              onOpenArticle={handleOpenArticle}
              onBackToHome={() => setCurrentView('home')}
            />
          )}

          {/* View 3: Admin CMS Dashboard */}
          {currentView === 'admin-dashboard' && (
            <AdminDashboard
              onCreateArticle={handleCreateNewArticle}
              onEditArticle={handleEditArticleFromAdmin}
              onOpenArticle={handleOpenArticle}
            />
          )}

          {/* View 4: Admin CMS Editor */}
          {currentView === 'admin-editor' && (
            <ArticleEditor
              articleId={selectedArticleId}
              onSaveSuccess={() => {
                loadArticles();
                setCurrentView('admin-dashboard');
              }}
              onCancel={() => setCurrentView('admin-dashboard')}
            />
          )}

          {/* View 5: Homepage / Category Feed */}
          {currentView === 'home' && (
            <div className="gn-feed-view animate-fade-in">
              
              {/* Horizontal Category Pill Bar */}
              <CategoryPills
                categories={categories}
                activeCategory={activeCategory}
                onSelectCategory={handleSelectCategory}
              />

              {/* Breaking News Ticker */}
              {breakingArticle && (
                <BreakingBanner
                  article={breakingArticle}
                  onOpenArticle={handleOpenArticle}
                />
              )}

              {/* Category Page Title if not Home */}
              {activeCategory !== 'home' && (
                <div className="gn-category-title-head">
                  <h2>{activeCategory.toUpperCase()} COVERAGE</h2>
                  <p>Latest stories and background context in {activeCategory}.</p>
                </div>
              )}

              {/* Two-Column Grid: Main Feed + Right Sidebar */}
              <div className="gn-feed-grid">
                
                {/* Main Feed Column */}
                <div className="gn-feed-main-column">
                  
                  {/* Lead Top Story Card */}
                  {featuredArticle && (
                    <TopStoryCard
                      article={featuredArticle}
                      relatedArticles={relatedToFeatured}
                      onOpenArticle={handleOpenArticle}
                    />
                  )}

                  {/* Section Blocks for Home View */}
                  {activeCategory === 'home' ? (
                    <>
                      {techArticles.length > 0 && (
                        <SectionBlock
                          title="Technology & Innovation"
                          categorySlug="technology"
                          articles={techArticles}
                          onSelectCategory={handleSelectCategory}
                          onOpenArticle={handleOpenArticle}
                        />
                      )}

                      {worldArticles.length > 0 && (
                        <SectionBlock
                          title="World News"
                          categorySlug="world"
                          articles={worldArticles}
                          onSelectCategory={handleSelectCategory}
                          onOpenArticle={handleOpenArticle}
                        />
                      )}

                      {businessArticles.length > 0 && (
                        <SectionBlock
                          title="Business & Markets"
                          categorySlug="business"
                          articles={businessArticles}
                          onSelectCategory={handleSelectCategory}
                          onOpenArticle={handleOpenArticle}
                        />
                      )}

                      {sportsArticles.length > 0 && (
                        <SectionBlock
                          title="Sports Coverage"
                          categorySlug="sports"
                          articles={sportsArticles}
                          onSelectCategory={handleSelectCategory}
                          onOpenArticle={handleOpenArticle}
                        />
                      )}
                    </>
                  ) : (
                    /* Category Filtered Articles Feed */
                    <div className="gn-category-feed-list">
                      {categoryArticles.slice(0, visibleArticleLimit).map((art) => (
                        <ArticleCard
                          key={art.id}
                          article={art}
                          variant="standard"
                          onOpenArticle={handleOpenArticle}
                        />
                      ))}

                      {visibleArticleLimit < categoryArticles.length && (
                        <button
                          className="gn-load-more-btn"
                          onClick={() => setVisibleArticleLimit(prev => prev + 6)}
                        >
                          Load More Coverage
                        </button>
                      )}
                    </div>
                  )}

                </div>

                {/* Right Column Sidebar */}
                <div className="gn-feed-right-column">
                  <WeatherWidget />
                  <EditorsPicksWidget
                    articles={articles}
                    onOpenArticle={handleOpenArticle}
                  />
                </div>

              </div>
            </div>
          )}

        </main>
      </div>

      <style>{`
        .gn-feed-grid {
          display: grid;
          grid-template-columns: 1fr 340px;
          gap: 24px;
          align-items: start;
        }

        .gn-category-title-head {
          margin-bottom: 20px;
          border-bottom: 1px solid var(--border-color);
          padding-bottom: 12px;
        }

        .gn-category-title-head h2 {
          font-size: 24px;
          font-weight: 700;
          color: var(--text-primary);
        }

        .gn-category-title-head p {
          font-size: 14px;
          color: var(--text-secondary);
        }

        .gn-category-feed-list {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .gn-load-more-btn {
          width: 100%;
          padding: 12px;
          border-radius: 24px;
          background-color: var(--bg-surface);
          border: 1px solid var(--border-color);
          color: var(--accent-color);
          font-size: 14px;
          font-weight: 600;
          margin-top: 12px;
          transition: background-color 0.15s;
        }

        .gn-load-more-btn:hover {
          background-color: var(--accent-light);
        }

        @media (max-width: 960px) {
          .gn-feed-grid {
            grid-template-columns: 1fr;
          }
          .gn-feed-right-column {
            order: 2;
          }
        }

        @media (max-width: 768px) {
          .content-body {
            margin-left: 0 !important;
          }
        }
      `}</style>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
