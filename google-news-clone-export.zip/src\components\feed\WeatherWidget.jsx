import React from 'react';
import { CloudSun, MapPin, Compass } from 'lucide-react';

export const WeatherWidget = () => {
  return (
    <div className="gn-weather-widget">
      <div className="gn-weather-header">
        <div className="gn-weather-location">
          <MapPin size={15} className="location-icon" />
          <span>New York, NY</span>
        </div>
        <span className="gn-weather-type">Local Briefing</span>
      </div>

      <div className="gn-weather-main">
        <CloudSun size={38} className="weather-icon" />
        <div className="gn-weather-temp">
          <span className="temp-val">72°</span>
          <span className="temp-unit">F</span>
        </div>
        <div className="gn-weather-details">
          <div className="condition">Partly Cloudy</div>
          <div className="sub-details">H: 76° • L: 62°</div>
        </div>
      </div>

      <style>{`
        .gn-weather-widget {
          background: linear-gradient(135deg, #e8f0fe 0%, #ffffff 100%);
          border: 1px solid var(--border-color);
          border-radius: var(--card-radius);
          padding: 16px;
          margin-bottom: 24px;
          box-shadow: var(--shadow-subtle);
        }

        .dark-theme .gn-weather-widget {
          background: linear-gradient(135deg, #2b384e 0%, #202124 100%);
        }

        .gn-weather-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 12px;
        }

        .gn-weather-location {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 13px;
          font-weight: 600;
          color: var(--text-primary);
        }

        .location-icon {
          color: var(--accent-color);
        }

        .gn-weather-type {
          font-size: 11px;
          font-weight: 600;
          color: var(--text-muted);
          text-transform: uppercase;
        }

        .gn-weather-main {
          display: flex;
          align-items: center;
          gap: 16px;
        }

        .weather-icon {
          color: #fbbc04;
        }

        .gn-weather-temp {
          display: flex;
          align-items: flex-start;
        }

        .temp-val {
          font-size: 32px;
          font-weight: 700;
          line-height: 1;
          color: var(--text-primary);
        }

        .temp-unit {
          font-size: 14px;
          font-weight: 600;
          color: var(--text-secondary);
          margin-top: 2px;
        }

        .gn-weather-details {
          display: flex;
          flex-direction: column;
        }

        .condition {
          font-size: 14px;
          font-weight: 500;
          color: var(--text-primary);
        }

        .sub-details {
          font-size: 12px;
          color: var(--text-muted);
        }
      `}</style>
    </div>
  );
};
